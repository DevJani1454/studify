const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json()); // Parse JSON request bodies

// MySQL Database connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'yourpassword', // Update with your MySQL password
    database: 'adaptive_learning'
});

// Connect to MySQL
db.connect(err => {
    if (err) {
        console.error('MySQL connection error:', err);
        return;
    }
    console.log('Connected to MySQL');
});

// Fetch all users
app.get('/api/users', (req, res) => {
    db.query('SELECT * FROM users', (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Error fetching users' });
        }
        res.json(results);
    });
});

// Fetch all lessons
app.get('/api/lessons', (req, res) => {
    db.query('SELECT * FROM lessons', (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Error fetching lessons' });
        }
        res.json(results);
    });
});

// Fetch all quizzes
app.get('/api/quizzes', (req, res) => {
    db.query('SELECT * FROM quizzes', (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: 'Error fetching quizzes' });
        }
        res.json(results);
    });
});

// Fetch adaptive learning path
app.get('/api/learning-path', (req, res) => {
    // Sample logic for a learning path, can be adjusted based on user progress
    const learningPath = {
        path: "Start with basic math, then move to intermediate, followed by advanced topics.",
        nextLesson: "Basic Math Lesson 1"
    };

    res.json(learningPath);
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
